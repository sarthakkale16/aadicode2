# mogenius
An Script to host telegram bot on mogenius.com

# Credits
- [ITZ-ZAID](https://github.com/ITZ-ZAID)
